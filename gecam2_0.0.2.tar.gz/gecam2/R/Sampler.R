upd_theta_cpp <- function(Y,
                          Mij,
                          L,
                          m0 = 0,
                          k0 = .1,
                          a = 3,
                          b = 2) {
  X = sample_model_parameters(Y, c(Mij) - 1, maxL = L, m0, k0, a, b)
  cbind(X[[1]], X[[2]])
}

upd_vk <- function(S, sd1, sd2, K) {
  N <- table(factor(S, levels = 1:K))
  C <- sum(N) - cumsum(N)
  rbeta(K, sd1 + N, sd2 + C)
}

upd_pi <- function(Sj, sd1, sd2, K) {
  V <- upd_vk(Sj, sd1, sd1, K)
  stick_breaking(V)
}

#' Title
#'
#' @param Y
#' @param G
#' @param s1
#' @param s2
#' @param p
#' @param nsim
#' @param sd1
#' @param sd2
#' @param L
#' @param K
#' @param m0
#' @param tau0
#' @param lambda0
#' @param gamma0
#'
#' @return
#' @export
#'
#' @examples
gibbs_gecam <-
  function(Y,
           G,
           p,
           nsim,
           burn = nsim / 2,
           s1,
           s2,
           sd1,
           sd2,
           L,
           K,
           m0 = 0,
           tau0 = .1,
           lambda0 = 3,
           gamma0 = 2,
           p_random = FALSE) {
    J <- length(unique(G))
    
    if (length(s1) == 1) {
      s1 = rep(s1, L)
    }
    if (length(s2) == 1) {
      s2 = rep(s2, L)
    }
    
    nj <- table(G)
    S  <- sample(1:K, J, T)
    
    Mij <- c(sample(1:(L - 5), length(Y), T))
    
    omega <- upd_omega_cpp(
      Mij - 1,
      Sj = S - 1,
      longS = rep(S - 1, nj) ,
      s1,
      s2,
      p = p,
      L = L,
      K = K
    )
    
    pi <-  upd_pi(S, sd1, sd2, K)
    theta <- upd_theta_cpp(Y, Mij, L)
    
    EMME <- array(NA, c(length(Y), nsim - burn))
    THET <- array(NA, c(L, 2, nsim - burn))
    ESSE <- matrix(NA, J, nsim - burn)
    PI <- matrix(NA, K, nsim - burn)
    X <- OMEGA <- array(NA, c(L, K, nsim - burn))
    PROBS <- numeric(nsim - burn)
    
    for (t in 1:nsim) {
      Mij <- upd_M_cpp(
        Y = Y,
        G = G - 1,
        theta = theta,
        omega = omega,
        Sj = S - 1,
        J = J,
        L = L
      )
      
      theta <- upd_theta_cpp(
        Y,
        Mij,
        L,
        m0 = m0,
        k0 = tau0,
        a = lambda0,
        b = gamma0
      )
      
      S <- upd_S_cpp(Y, G - 1, J, theta, pi, omega, K = K, L = L)
      
      pi <- upd_pi(S, sd1, sd1, K = K)
      
      omega <-    upd_omega_cpp(
        Mij - 1,
        Sj = S - 1,
        longS = rep(S - 1, nj) ,
        s1,
        s2,
        p = p,
        L,
        K
      )
      
      if (p_random) {
        p <- rbeta(1, 1 + sum(omega == 0), 1 + sum(omega != 0))
      }
      
      if (t %% 100 == 0)
        cat(paste(t), "\n")
      
      
      if (t > burn) {
        OMEGA[, , t - burn] <- omega
        PI[, t - burn]      <- pi
        ESSE[, t - burn]    <- S
        THET[, , t - burn]  <- theta
        EMME[, t - burn]    <- Mij
        PROBS[t - burn]     <- p
      }
      
    }
    
    return(list(
      EM = t(EMME),
      TH = THET,
      ES = t(ESSE),
      PI = PI,
      OM = OMEGA,
      PROBS = PROBS,
      Y = Y,
      G = G
    ))
  }



#' Title
#'
#' @param res
#' @param howmany
#' @param yseq
#' @param s
#'
#' @return
#' @export
#'
#' @examples
draw_dens <- function(res,
                      howmany = 10,
                      yseq = seq(-15, 15, by = .1),
                      s = 1) {
  RES = matrix(NA, howmany, length(yseq))
  nsim = ncol(res$PI)
  L = nrow(res$TH)
  for (t in (nsim - howmany + 1):nsim) {
    RES[t - (nsim - howmany), ] <- rowSums(sapply(1:L, function(x)
      res$OM[x, res$ES[t, s], t] * dnorm(yseq, res$TH[, , t][x, 1], sqrt(res$TH[, , t][x, 2]))))
  }
  
  plot(RES[t - (nsim - howmany), ] ~ yseq, type = "l")
  for (t in (nsim - howmany + 1):nsim) {
    lines(RES[t - (nsim - howmany), ] ~ yseq, col = "gray")
  }
  lines(
    colMeans(RES) ~ yseq,
    col = "darkblue",
    type = "b",
    cex = .4
  )
}


#' Title
#'
#' @param res
#' @param howmany
#' @param yseq
#' @param s
#'
#' @return
#' @export
#'
#' @examples
avg_dens <- function(res,
                     howmany = 10,
                     yseq = seq(-15, 15, by = .1),
                     s = 1) {
  RES = matrix(NA, howmany, length(yseq))
  nsim = ncol(res$PI)
  L = nrow(res$TH)
  for (t in (nsim - howmany + 1):nsim) {
    RES[t - (nsim - howmany), ] <- rowSums(sapply(1:L, function(x)
      res$OM[x, res$ES[t, s], t] * dnorm(yseq, res$TH[, , t][x, 1], sqrt(res$TH[, , t][x, 2]))))
  }
  
  return(cbind(colMeans(RES), yseq))
}


#' Title
#'
#' @param res
#' @param howmany
#' @param yseq
#' @param s
#'
#' @return
#' @export
#'
#' @examples
MCMC_KLD <- function(res,
                     howmany = 10,
                     yseq = seq(-15, 15, by = .1),
                     s = 1,
                     fun) {
  RES = matrix(NA, howmany, length(yseq))
  nsim = ncol(res$PI)
  L = nrow(res$TH)
  for (t in (nsim - howmany + 1):nsim) {
    RES[t - (nsim - howmany), ] <- rowSums(sapply(1:L, function(x)
      res$OM[x, res$ES[t, s], t] * dnorm(yseq, res$TH[, , t][x, 1], sqrt(res$TH[, , t][x, 2]))))
  }
  w1 <- apply(RES, 1, function(x)
    KLD(x, fun(yseq))$mean.sum.KLD)
  return(w1)
}
