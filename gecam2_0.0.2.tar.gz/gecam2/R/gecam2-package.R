## usethis namespace: start
#' @importFrom Rcpp sourceCpp
## usethis namespace: end
NULL
## usethis namespace: start
#' @useDynLib gecam2, .registration = TRUE
## usethis namespace: end
NULL