#include <RcppArmadillo.h>
//[[Rcpp::depends(RcppArmadillo)]]
#include <RcppArmadilloExtensions/sample.h>
using namespace Rcpp;

//---------
int sample_i(arma::vec ids, arma::vec prob)
{
  int out ;
  prob = prob/arma::accu(prob);
  out = Rcpp::RcppArmadillo::sample(ids, 1, false, prob)[0] ;
  // Rcpp::Rcout << prob;
  return(out) ;
}
//---------
int sample_i_logprob(arma::vec ids, arma::vec log_prob)
{
  int out ;
  arma::vec llprob = log_prob - max(log_prob);
  arma::vec prob = exp(llprob)/arma::accu(exp(llprob));
  out = Rcpp::RcppArmadillo::sample(ids, 1, false, prob)[0] ;
  // Rcpp::Rcout << prob;
  return(out) ;
}


// [[Rcpp::export]]
Rcpp::List sample_model_parameters(const arma::vec& y,
                                   arma::vec M_iter,
                                   int maxL,
                                   double m0, 
                                   double tau0,
                                   double lambda0, 
                                   double gamma0)
{
  arma::vec out_mu(maxL) ;
  arma::vec out_sigma2(maxL) ;
  
  double new_m0 ; double new_tau0 ;
  double new_lambda0; double new_gamma0 ;
  
  for(int l = 0; l < maxL ; l++)
  {
    arma::uvec M_l = find( M_iter == l ) ;
    int n_l = M_l.n_elem ;
    
    if( n_l > 0) {
      
      double sum_l = arma::accu( y(M_l) ); // sum of y_i
      
      // new parameters
      new_tau0 = tau0 + n_l ;
      new_m0 = (tau0 * m0 + sum_l)/new_tau0 ;
      new_lambda0 = lambda0 + 0.5 * n_l ;
      new_gamma0 = gamma0 + 0.5 * ( (n_l - 1.0)*arma::var(y(M_l)) + 
                   (tau0*n_l)/new_tau0 * (sum_l/n_l - m0) * (sum_l/n_l - m0)  ) ;
      
      
      out_sigma2(l) = 1/R::rgamma( new_lambda0, 1.0/new_gamma0) ;
      out_mu(l) = R::rnorm( new_m0, sqrt(out_sigma2(l)/new_tau0) ) ;
      
    } else {
      out_sigma2(l) = 1/R::rgamma(lambda0, 1.0/gamma0) ;
      out_mu(l) = R::rnorm( m0, sqrt(out_sigma2(l)/tau0) )  ;
    }
  }
  
  return Rcpp::List::create(Rcpp::Named("out_mu") = out_mu,
                            Rcpp::Named("out_sigma2") = out_sigma2);
}


// [[Rcpp::export]]
arma::vec stick_breaking(arma::vec beta_var)
{
  int len = beta_var.n_elem ;
  arma::vec out(len) ;
  out(0) = beta_var(0) ;
  arma::vec cs_log_one_m_beta = arma::cumsum(log(1.0-beta_var));
  for(int k = 1; k < len; k++)
  {
    out(k) = exp( log(beta_var(k)) + cs_log_one_m_beta(k-1)) ;
  }
  return(out) ;
}

// [[Rcpp::export]]
arma::vec upd_S_cpp( arma::vec Y, arma::vec G, int J, 
                     arma::mat theta, arma::vec pi,
                     arma::mat omega, int K, int L){
  
  arma::vec Sj(J);
  arma::vec PR(K);
  arma::vec distr_cluster_id = arma::linspace(0, K-1, K) ;
  
  for(int j=0; j<J; j++){
    
    arma::uvec ind_jth_group = find(G == j);
    int nj = ind_jth_group.n_elem;
    
    arma::mat PHI(nj,L);
    
    for(int l=0; l<L; l++){
      PHI.col(l) = arma::normpdf( Y.elem(ind_jth_group), 
                                theta(l,0), sqrt(theta(l,1)));
    }
    
    for(int k=0; k<K; k++){
      arma::mat Gin = arma::repelem(omega.col(k),1,nj); // L x N;
      PR(k) = log(pi(k)) + arma::accu( // sum over nj
        log(
        arma::sum(Gin.t()%PHI,1) // sum over L
                                        ));
    }
    
    Sj[j] =  sample_i_logprob(distr_cluster_id, (PR)) ;
  }
  
  return(Sj+1);
}


// [[Rcpp::export]]
arma::mat upd_omega_cpp(arma::vec Mij,
                        arma::vec Sj,
                        arma::vec longS,
                        arma::vec s1,
                        arma::vec s2,
                        double p, int L, int K){
  
  arma::mat U(L,K);
  arma::mat Omega = U;
  arma::vec zero_one = arma::linspace(0, 1, 2) ;
  arma::vec prior_p(2);
  prior_p[0] = p;
  prior_p[1] = 1-p;
  
  for(int k=0; k<K; k++){
    
    arma::uvec inds = arma::find(longS == k);
    
    if((inds.n_elem)==0){
      arma::colvec xx = Rcpp::RcppArmadillo::sample(zero_one, L, true, prior_p);
      for(int l=0; l<L;l++){
        U(l,k) = R::rbeta(s1(l) * xx(l), s2(l));
      }
    }else{
      arma::vec Msub = Mij.elem(inds);
      for(int l=0; l<L;l++){
        arma::uvec Nv = find(Msub == l);
        arma::uvec Cv = find(Msub > l);
        int nlk = Nv.n_elem;
        int cum_nlk = Cv.n_elem;
        //Rcout<< N << "---" << C;
        int x = 1;
        if(p>0){
          double lpact = log(1-p) + R::lbeta(s1(l) + nlk, s2(l) + cum_nlk) -
                                    R::lbeta(s1(l),s2(l));
          double poff  = (p)* (nlk==0);
          if( R::runif(0,1) > exp(lpact)/(exp(lpact)+(poff)) ){x=0;}
        }
        U(l,k) = R::rbeta(s1(l) * x + nlk , s2(l)+cum_nlk);
      }
    }
    Omega.col(k) = stick_breaking(U.col(k));
  }
  return(Omega);
}


// [[Rcpp::export]]
arma::vec upd_M_cpp(arma::vec Y, arma::vec G,
                    arma::mat theta,
                    arma::mat omega,
                    arma::vec Sj,
                    int J,int L){
  arma::vec Mij = Y;
  int z=0;
  arma::vec obs_cluster_id = arma::linspace(0, L-1, L) ;
  
  for(int j=0; j<J; j++){
    
    arma::uvec inds = find(G==j);
    arma::vec subY = Y.elem(inds);
    int nj = subY.n_elem;
    
    for(int i=0; i < nj; i++){
      arma::vec py(L);
      for(int l=0; l<L; l++){
        py(l) = arma::normpdf(subY[i], theta(l,0), sqrt(theta(l,1)));
      }
      arma::vec lp = log(omega.col(Sj[j])) + log(py);
      Mij(z+i)     =  sample_i_logprob(obs_cluster_id, lp ) ;
    }
    z += nj;
  }
  return(Mij+1);
}
